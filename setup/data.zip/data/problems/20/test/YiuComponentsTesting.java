/*
ACM ICPC Southeast USA Regional Contest 2012
Problem: Components Testing

Author: Yiu Yu Ho

This is a correct and efficient solution.
*/

import java.io.*;
import java.util.*;

public class YiuComponentsTesting
{
  private static class Pair implements Comparable<Pair>
  {
    public long count, value;
    
    public Pair(long countIn, long valueIn)
    {
      count = countIn;
      value = valueIn;
    }

    public int compareTo(Pair u)
    {
      long c = (value - u.value);
      if (c != 0) return (c < 0 ? -1 : 1);
      return 0;
    }
  }

  private Scanner in = new Scanner(System.in);
  private PrintStream out = System.out;

  private Pair[] C, E;
  private int Cn, En;

  private void main()
  {
    Cn = in.nextInt();
    En = in.nextInt();
    while (Cn > 0)
    {
      C = new Pair[Cn];
      for (int i = 0; i < Cn; ++i) C[i] = new Pair(in.nextInt(), in.nextInt());

      E = new Pair[En];
      for (int j = 0; j < En; ++j) E[j] = new Pair(in.nextInt(), in.nextInt());

      Arrays.sort(C);
      Arrays.sort(E);

      long n = 0;
      long base = 0;
      for (Pair c : C)
      {
        base += c.count * c.value;
        n += c.count;
      }

      long cut = 0;
      for (Pair e : E) cut += e.count * e.value;

      long OPT = Math.min(base, cut);

      int x, y, i, j;

      x = 0; y = 0;
      i = 0; j = En - 1;
      while (i < Cn && j >= 0)
      {
        for (int k = 0; k < E[j].count && i < Cn; ++k)
        {
          ++x;
          cut -= E[j].value;
          cut += (n - y);
          
          while (i < Cn && C[i].value <= x)
          {
            y += C[i].count;
            cut -= x * C[i].count;
            cut += C[i].value * C[i].count;

            ++i;
          }

          OPT = Math.min(OPT, cut);
        }

        --j;
      }

      out.println(OPT >= base ? "Yes" : "No");

      Cn = in.nextInt();
      En = in.nextInt();
    }
  }

  public static void main(String[] args)
  {
    long startTime = System.currentTimeMillis();
    (new YiuComponentsTesting()).main();
    long endTime = System.currentTimeMillis();

    System.err.println("Time = " + (endTime - startTime) + "(ms)");
  }
}
