import java.io.*;
import java.util.*;
import java.awt.*;

class lock_judge
{
    public Scanner sc;
    public PrintStream ps;

    public String toString()
    {
        return "lock_judge";
    }

    public void doit() throws Exception
    {
        sc = new Scanner( System.in );
        ps = System.out;

        for(;;)
        {
            // Read input, break if at end
            int n = sc.nextInt();
            int t1 = sc.nextInt();
            int t2 = sc.nextInt();
            int t3 = sc.nextInt();
            if( n==0 && t1==0 && t2==0 && t3==0 ) break;

            // The worst possible case is that you start out n-1 away from t1.
            // Tally up the number of clicks like this:
            //
            // Go around once:          n
            // Go around again:         n
            // Go to T1:                n-1
            //
            // Go the other way around: n
            // Go from T1 to T2.        (t2-t1+n)%n (see Note)
            //
            // Go from T2 to T3         (t2-t3+n)%n (see Note)
            // ------------------------------------
            // Total                     4n + (t2-t1+n)%n + (t2-t3+n)%n - 1
            ps.println( 4*n + (t2-t1+n)%n + (t2-t3+n)%n - 1 );

            // Note: How many clicks is it from t1 to t2? Well, turning the dial 
            // counter-clockwise, the numbers go up. If t2>t1, then you just 
            // go straight from t1 to t2, and the answer is t2-t1. If t2<t1, then you
            // go up from t1 to n (which is the same as 0), and then from 0 to t2. 
            // That's n-t1 + t2. Either way, (t2-t1+n)%n covers it.
            //
            // To go to from t2 to t3, it's the same logic, except the dial
            // is spinning the other way and the numbers go down.
            // Then, you get (t2-t3+n)%n.
        }
    }

	public static void main(String[] args) throws Exception
	{
		new lock_judge().doit();
	}
}
