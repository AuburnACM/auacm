/*
Author: Yiu Yu Ho
*/

import java.util.*;
import java.io.*;

public class lock
{
	public Scanner in = new Scanner(System.in);
	public PrintStream out = System.out;
	
	public int n;
	
	public void main()
	{
		int T1,T2,T3;
		n = in.nextInt();
		while(n>0)
		{
			T1=in.nextInt();
			T2=in.nextInt();
			T3=in.nextInt();
			
			out.println(4*n-1+ccw(T1,T2)+cw(T2,T3));
			
			n=in.nextInt();
		}
	}
	
	public int ccw(int a,int b)
	{
		if(a<=b) return b-a;
		return n-a+b;
	}
	
	public int cw(int a,int b) { return n-ccw(a,b); }
	
	public static void main(String[] args)
	{
		long startTime = System.currentTimeMillis();
		(new lock()).main();
		System.err.println("Time = "+(System.currentTimeMillis()-startTime)+"ms");
	}
}
