
import java.io.*;
import java.util.*;
import java.awt.geom.*;

/**
 * Solution to Collision Detection
 * 
 * @author vanb
 */
public class collisiondetection2
{
    public Scanner sc;
    public PrintStream ps;
    
    public static final double EPSILON = 0.000001;
    
    // TOLERANCE is the square of 18, which is the distance 
    // considered dangerous. For simplicity, we're going to
    // measure distance^2 rather than distance
    public static final double TOLERANCE = 18.0*18.0;
    
    /**
     * All of the movement parameters of a car
     * 
     * @author vanb
     */
    public class Car
    {
        // Input parameters: Time, velocity, and (x,y) position for two readings
        public double v1, v2, t1, t2, x1, x2, y1, y2;
        
        // Computed things: 
        // a = acceleration
        // cos, sin = cosine and sine of angle of movement
        // vf = velocity at time of freeze (when the car hits either 0 or 80)
        // tf = time of freeze
        // (xf,yf) = position of freeze
        public double a, cos, sin, vf, tf, xf, yf;
        
        /**
         * Create a Car
         * 
         * @param t1 Time 1
         * @param x1 x of (x1,y1) position
         * @param y1 y of (x1,y1) position
         * @param v1 Speed 1
         * @param t2 Time 2
         * @param x2 x of (x2,y2) position
         * @param y2 y of (x2,y2) position
         * @param v2 Speed 2
         */
        public Car( double t1, double x1, double y1, double v1,
                    double t2, double x2, double y2, double v2)
        {
            this.t1 = t1;
            this.x1 = x1;
            this.y1 = y1;
            this.v1 = v1;
            this.t2 = t2;
            this.x2 = x2;
            this.y2 = y2;
            this.v2 = v2;
            
            // Acceleration
            a = (v2-v1)/(t2-t1);
            
            // Angle
            double theta = Math.atan2( y2-y1, x2-x1 );
            cos = Math.cos( theta );
            sin = Math.sin( theta );
            
            // Terminal velocity
            vf = Math.abs(a)<EPSILON ? v2 : a>0.0 ? 80.0 : 0.0;
            
            // Time of Freeze
            tf = Math.abs(a)<EPSILON ? t2 :(vf + a*t2 - v2)/a;
            
            // Position of freeze
            // dt = delta time
            double dt = tf-t2;
            xf = x2 + 0.5*a*cos*dt*dt + v2*cos*dt;
            yf = y2 + 0.5*a*sin*dt*dt + v2*sin*dt;   
        }
        
        /**
         * X coordinate at time t
         * 
         * @param t Time
         * @return X coordinate at t
         */
        public double x( double t )
        {
            double result = 0.0;
            double dt = t-t1;
            if( t<tf ) result = x1 + 0.5*a*cos*dt*dt + v1*cos*dt;
            else result = xf + vf*cos*(t-tf);
            
            return result;
        }
        
        /**
         * Y coordinate at time t
         * 
         * @param t Time
         * @return Y coordinate at t
         */
        public double y( double t )
        {
            double result = 0.0;
            double dt = t-t1;
            if( t<tf ) result = y1 + 0.5*a*sin*dt*dt + v1*sin*dt;
            else result = yf + vf*sin*(t-tf);
            
            return result;
        }
    }
    
    /**
     * Distance squared between the cars at time t
     * 
     * @param c1 One car
     * @param c2 Another car
     * @param t Time
     * @return Distance^2 between c1 and c2 at time t
     */
    public double d2( Car c1, Car c2, double t )
    {
        double x = c2.x(t)-c1.x(t);
        double y = c2.y(t)-c1.y(t);
        return x*x + y*y;
    }
    
    /**
     * Driver.
     * @throws Exception
     */
    public void doit() throws Exception
    {
        sc = new Scanner( System.in ); //new File( "collisiondetection.judge" ) );
        ps = System.out; //new PrintStream( new FileOutputStream( "collisiondetection.solution" ) ); 
                        
        for(;;)
        {
            // First point
            double t1 = sc.nextDouble();
            double x1 = sc.nextDouble();
            double y1 = sc.nextDouble();
            double v1 = sc.nextDouble();          
            if( t1<0.0 && x1<0.0 && y1<0.0 && v1<0.0 ) break;
            
            // Second point
            double t2 = sc.nextDouble();
            double x2 = sc.nextDouble();
            double y2 = sc.nextDouble();
            double v2 = sc.nextDouble();
            double tmax = t2;            
            Car car1 = new Car( t1, x1, y1, v1, t2, x2, y2, v2 );
            
            // Third point (First of car 2)
            t1 = sc.nextDouble();
            x1 = sc.nextDouble();
            y1 = sc.nextDouble();
            v1 = sc.nextDouble();          

            // Fourth point (Second of Car 2)
            t2 = sc.nextDouble();
            x2 = sc.nextDouble();
            y2 = sc.nextDouble();
            v2 = sc.nextDouble();    
            if( t2>tmax ) tmax = t2;
            Car car2 = new Car( t1, x1, y1, v1, t2, x2, y2, v2 );
            
            // Find a time when the cars are within the tolerance of each other
            double time = tmax;
            while( d2(car1, car2, time) > TOLERANCE && time<=tmax+30.0 ) time += 0.00001;                            
            ps.println( time>tmax+30.0 ? 0 : 1 );         
        }
    }
    
    /**
     * @param args
     */
    public static void main( String[] args ) throws Exception
    {
        new collisiondetection2().doit();
    }

}
