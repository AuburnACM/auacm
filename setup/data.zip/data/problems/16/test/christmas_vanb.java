
import java.io.*;
import java.util.*;
import java.awt.geom.*;

/**
 * Solution to The n Days of Christmas
 * 
 * @author vanb
 */
public class christmas_vanb
{
    public Scanner sc;
    public PrintStream ps;
    
    
    /**
     * Driver.
     * @throws Exception
     */
    public void doit() throws Exception
    {
        sc = new Scanner( System.in ); //new File( "christmas.judge" ) );
        ps = System.out; //new PrintStream( new FileOutputStream( "christmas.solution" ) );

        // Precompute all of the answers
        long gifts[] = new long[1000001];
        gifts[1] = 1L;
        for( int i=2; i<=1000000; i++ )
        {
            // On day i, you get Sum(1..i) gifts. That's i*(i+1)/2
            // Add in the accumulation of all the gifts from the day before.
            long ii = i;
            gifts[i] = ii*(ii+1)/2L + gifts[i-1]; 
        }

        for(;;)
        {
            int n = sc.nextInt();
            if( n==0 ) break;
            ps.println( gifts[n] );
        }
    }
    
    /**
     * @param args
     */
    public static void main( String[] args ) throws Exception
    {
        new christmas_vanb().doit();        
    }   
}
