import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Christmas_artur {

  public static void main(String[] args) throws Exception {
    BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    for (long n = Integer.parseInt(in.readLine()); n != 0; n = Integer.parseInt(in.readLine()))
      System.out.println(n * (n + 1) / 2 * (n + 2) / 3);
  }
}
