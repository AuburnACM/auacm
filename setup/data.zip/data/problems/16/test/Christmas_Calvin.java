import java.util.Scanner;

public class Christmas_Calvin {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		while(in.hasNext()) {
			int n = in.nextInt();
			if (n == 0) {
				break;
			}
			System.out.println(n*(n+1)*(n+2)/6);
		}
		in.close();
	}
}
