
import java.io.*;
import java.util.*;
import java.awt.geom.*;

/**
 * Solution to Decimal Representation
 * 
 * @author vanb
 */
public class decimal_vanb
{
    public Scanner sc;
    public PrintStream ps;
    
    // Max n
    public static final int MAX = 500;
    
    // We'll use this to see when remainders repeat
    // when figuring out the decimal representation
    public boolean seen[] = new boolean[MAX*10+1];
    
    /**
     * Length of decimal representation of num/den
     * 
     * @param num Numerator
     * @param den Denominator
     * @return Length of decimal representation of num/den
     */
    public int declen( int num, int den )
    {        
        // Count the number of digits before the '.'
        int i = num/den;
        int result = 1;
        if( i>9 ) ++result;
        if( i>99 ) ++result;
        
        // If the number has decimal places
        if( num%den > 0 )
        {
            //Count the '.'
            ++result;
    
            // Haven't seen any remainders yet
            Arrays.fill( seen, false );
            
            // Count the number of digits until a repeat
            int count = 0;
            int remainder = 0;
            num = (num%den)*10;
            for(;;)
            {
                remainder = num % den;
                if( remainder==0 || seen[num] ) break;
                seen[num] = true;
                ++count;
                num = remainder*10;
            }
            
            result += count;
            
            // If remainder is not 0, then we're got to count the ()s
            // If remainder is 0, then we stopped one short.
            if( remainder!=0 ) result += 2; else ++result;
        }
        return result;
    }
     
    /**
     * Driver.
     * @throws Exception
     */
    public void doit() throws Exception
    {
        sc = new Scanner( new File( "decimal.judge" ) );
        ps = new PrintStream( new FileOutputStream( "decimal.solution" ) );

        // Precalculate all 500 answers
        int best[] = new int[MAX+1];
        best[1] = 1;
        for( int i=2; i<=MAX; i++ )
        {
            // Start with the previous best. That's
            // the best we can do, a/b, with a,b<i
            best[i] = best[i-1];
            for( int j=1; j<=i; j++ )
            {
                // Now, all we need to check is i/j and j/i.
                int len = declen( i, j );
                if( len>best[i] ) best[i] = len;
                len = declen( j, i );
                if( len>best[i] ) best[i] = len;
            }
        }
        
        for(;;)
        {
            int n = sc.nextInt();
            if( n==0 ) break;
            
            ps.println( best[n] );
        }
    }
    
    /**
     * @param args
     */
    public static void main( String[] args ) throws Exception
    {
        new decimal_vanb().doit();
    }   
}
