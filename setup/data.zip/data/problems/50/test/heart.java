/*
Author: Yiu Yu Ho

This problem requires a fixed point solution as follows.

(1) Let H = { all cities } be the heart of the kingdom.  
    Note that H may not be defensible.
(2) Let sum(v) be the number of troops stationed in city v and its neighbors 
    in H, this invariant is kept throughout.
(3) While there is any city x in H with sum(x) < K, remove x from H, update sum accordingly.
(4) When all vertices x in H has sum(x) >= K, H is the largest defensible set, simply count 
    the number of vertices and sum up the troops.
*/

import java.util.*;
import java.io.*;

public class heart
{
	public BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
	public PrintStream out = System.out;

	public int n,K;
	public int[][] GE;
	public int[] T, sum;
	public boolean[] inH;

	public void main()
	{
		try
		{
			int i,j,k,x,y,M;
			boolean done;
			StringTokenizer tok;
			
			tok=new StringTokenizer(in.readLine());
			n=new Integer(tok.nextToken());
			K=new Integer(tok.nextToken());

			while(n>0)
			{
				GE=new int[n][];
				T=new int[n];
				sum=new int[n];
				inH=new boolean[n];
				
				for(i=0;i<n;++i)
				{
					tok = new StringTokenizer(in.readLine());
					T[i]=new Integer(tok.nextToken());
					M = new Integer(tok.nextToken());
					GE[i]=new int[M];

					for(x=0;x<GE[i].length;++x) GE[i][x]=new Integer(tok.nextToken());
				}

				Arrays.fill(inH,true);
				
				for(i=0;i<n;++i)
				{
					sum[i]=T[i];
					for(x=0;x<GE[i].length;++x)
					{
						j=GE[i][x];
						sum[i]+=T[j];
					}
				}

				done=false;
				while(!done)
				{
					done=true;
					for(i=0;i<n;++i)
					if(inH[i] && sum[i]<K)
					{
						inH[i]=false;
						done=false;

						for(x=0;x<GE[i].length;++x)
						{
							j=GE[i][x];
							sum[j]-=T[i];
						}
					}
				}
				
				int size, troop;
				size=troop=0;

				for(i=0;i<n;++i)
				if(inH[i])
				{
					++size;
					troop+=T[i];
				}

				out.println(size+" "+troop);
				
				tok=new StringTokenizer(in.readLine());
				n=new Integer(tok.nextToken());
				K=new Integer(tok.nextToken());
			}//end while(n>0)
		}
		catch(IOException ioe) { ioe.printStackTrace(); }
	}//end void main()

	public static void main(String[] args) 
	{
		long startTime = System.currentTimeMillis();
		(new heart()).main();
		System.err.println("Time = "+(System.currentTimeMillis()-startTime)+"(ms)");
	}
}
