import java.io.*;
import java.util.*;
import java.awt.*;

class heart_judge
{
    public Scanner sc;
    public PrintStream ps;

    public String toString()
    {
        return "heart_judge";
    }

    public void doit() throws Exception
    {
        sc = new Scanner( System.in );
        ps = System.out;

        // Look for nodes with available troops < k, and remove them, and remove all of their edges.
        // This will affect the troops of their neighbors.
        // Keep going until there are no more nodes with troops<k
        // The nodes that are left are the heart.
        //
        // We'll use something like a breadth-first search. We'll remove nodes, and put them on a queue.
        // So, the queue will hold freshly removed nodes.
        // Take a node off the queue, reduce the troops of its neighbors, and put a neighbor on the
        // queue if its available troops go below k.
        for(;;)
        {
            // Read n, k, break if at end
            int n = sc.nextInt();
            if( n==0 ) break;
            int k = sc.nextInt();

            // Graph adjacency matrix
            boolean neighbors[][] = new boolean[n][n];

            // The number of troops in this city
            int troops[] = new int[n];

            // The number of troops available to this city.
            // That is, those in this city and its immediate neighbors
            int totaltroops[] = new int[n];

            // For the BFS - if a node gets "visited", then it can't be supported,
            // and it's not in the heart_judge.
            boolean visited[] = new boolean[n];
            Arrays.fill( visited, false );

            // Start by reading the data.
            for( int i=0; i<n; i++ )
            {
                // Read troops for this city
                troops[i] = sc.nextInt();

                Arrays.fill( neighbors[i], false );

                // Read number of neighbors
                int m = sc.nextInt();

                // Fill in the adjacency matrix
                for( int j=0; j<m; j++ )
                {
                    int neighbor = sc.nextInt(); 
                    neighbors[i][neighbor] = true;
                }
            }

            // This will be the queue for a BFS-like algorithm
            LinkedList<Integer> queue = new LinkedList<Integer>();

            // Go through and compute totaltroops
            for( int i=0; i<n; i++ )
            {
                // totaltroops is the sum of the troops here,
                // and at all neighbors
                totaltroops[i] = troops[i];
                for( int j=0; j<n; j++ ) if( neighbors[i][j] ) 
                {
                    totaltroops[i] += troops[j];
                }

                // If there aren't enough total troops to defend this city,
                // then put it on the queue, and mark it as "visited"
                if( totaltroops[i]<k )
                {
                    queue.add( i );
                    visited[i] = true;
                }
            }

            // While there are more nodes to look at
            // Remember, these are cities that can't be defended.
            while( queue.size()>0 )
            {
                // Get a fallen city
                int city = queue.removeFirst();

                // Go through its neighbors
                for( int neighbor=0; neighbor<n; neighbor++) if( neighbors[city][neighbor] ) 
                {
                    // This city can't be defended.
                    // Therefore, its troops can't be counted on to defend its neighbors.
                    totaltroops[neighbor] -= troops[city];

                    // If this neighbor hasn't yet been visited and
                    // it's now below our k threshold, then it can't be defended.
                    // Mark it and put it on the queue.
                    if( !visited[neighbor] && totaltroops[neighbor]<k )
                    {
                        visited[neighbor] = true;
                        queue.add( neighbor );
                    }
                }
            }

            // Now, just go through the list, tallying the unvisited nodes.
            // They're the ones which haven't been removed, so they form the Heart of the Country
            int ncities = 0;
            int ntroops = 0;
            for( int i=0; i<n; i++ ) if( !visited[i] )
            {
                ++ncities;
                ntroops += troops[i];
            }

            ps.println( ncities + " " + ntroops );
        }
    }

	public static void main(String[] args) throws Exception
	{
		new heart_judge().doit();
	}
}
