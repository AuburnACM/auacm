# idx, start, up, prefix

C_={}
def C(idx, start, up, prefix, w):
	if C_.has_key((idx, start, up, prefix)):
		return C_[(idx, start, up, prefix)]
	if idx==len(w):
		return 1

	q=0
	for d in range(10):
		#Can I use digit d at this idx?
		if prefix and d>w[idx]:
			break

		if not up and d>start:
			break

		q+=C(idx+1,d,up and d>=start,prefix and d==w[idx],w)
	C_[(idx, start, up, prefix)]=q
	return q

def isHill(w):
	up=True

	for i in range(1,len(w)):
		if up and w[i]>=w[i-1]:
			continue
		if up and w[i]<w[i-1]:
			up=False
			continue
		if w[i]>w[i-1]:
			return False
	return True

if __name__ == '__main__':
	w=[int(x) for x in list(raw_input())]
	if isHill(w):
		print C(0, 0, True, True, w) - 1
	else:
		print -1