import java.io.*;
import java.util.*;
import java.awt.*;

class circuits_judge
{
    public Scanner sc;
    public PrintStream ps;

    public String toString()
    {
        return "circuits_judge";
    }

    // Mapping of numbers to letters. For debugging only.
    public final char letters[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();

    // counts[i] is the number of connections at node i
    public int counts[] = new int[26];

    // resistance[i][j] is the resistance between nodes i and j
    public double resistance[][] = new double[26][26];

    // Place a resistor between i and j with resistance r
    public void place( int i, int j, double r )
    {
        // If there's no resistor there already
        if( resistance[i][j] < 0.0 )
        {
            // Record it, and increment the number of resistors at nodes i & j.
            resistance[i][j] = resistance[j][i] = r;
            ++counts[i];
            ++counts[j];
        }
        else
        {
            // If there's already a resistor here, then this one is in parallel.
            // Reduce to one resistor.
            resistance[i][j] = resistance[j][i] = 1.0/(1.0/r + 1.0/resistance[i][j]);
        }
    }

    // Debugging tool
    public void dump()
    {
        for( int i=0; i<counts.length; i++ ) if( counts[i]>0 )
        {
            System.out.println( "counts[" + letters[i] + "]=" + counts[i] );
        }

        for( int i=0; i<26; i++ ) for( int j=0; j<26; j++ ) if( resistance[i][j] > -0.5 )
        {
            System.out.println( "resistance[" + letters[i] + "][" + letters[j] + "]=" + resistance[i][j] );
        }
    }

    public void doit() throws Exception
    {
        sc = new Scanner( new File( "circuits.judge" ) );
        ps = System.out;

        for(;;)
        {
            // Read n, break if end of data
            int n = sc.nextInt();
            if( n==0 ) break;

            // Initialize structures
            Arrays.fill( counts, 0 );
            for( int i=0; i<26; i++ )
            {
                Arrays.fill( resistance[i], -1.0 );
            }

            // Read input, place resistors
            for( int i=0; i<n; i++ )
            {
                int n1 = (int)(sc.next().toUpperCase().charAt(0)-'A');
                int n2 = (int)(sc.next().toUpperCase().charAt(0)-'A');
                double res = sc.nextDouble();
                place( n1, n2, res );
            }

            //dump();

            // Look for resistors in series.
            // The method place() will take care of parallel resistors. 
            // If two resistors are in series, then their mid node will have exactly 2 connections.
            // Special case: we've got to exclude A and Z. As in and out, they each have an extra
            // connection, and thus can never be the midpoint of resistors in series.

            // Keep going until there are no more changes
            boolean changed = true;
            while( changed )
            {
                changed = false;

                // Skip A(0) and Z(25), look for nodes with exactly 2 connections
                for( int i=1; i<25; i++ ) if( counts[i]==2 )
                {
                    // Look for the first connection. Remember the node, and the resistance.
                    int n1 = -1;
                    double r1 = 0.0;
                    for( int j=0; j<26; j++ ) if( resistance[i][j] > -0.5 )
                    {
                        n1 = j;
                        r1 = resistance[i][j];
                        break;
                    }

                    // Look for the second connection
                    int n2 = -1;
                    double r2 = 0.0;
                    for( int j=n1+1; j<26; j++ ) if( resistance[i][j] > -0.5 )
                    {
                        n2 = j;
                        r2 = resistance[i][j];
                        break;
                    }

                    // Remove the resistors from n1 to i, and i to n2 
                    counts[i] = 0;
                    --counts[n1];
                    --counts[n2];
                    resistance[i][n1] = resistance[n1][i] = -1.0;
                    resistance[i][n2] = resistance[n2][i] = -1.0;

                    // Replace them with a single resistor from n1 to n2
                    place( n1, n2, r1+r2 );

                    // We made a change
                    changed = true;

                    //dump();
                }
            }

            // Now, we should be left with a single resistor between A and Z. 
            // If not, then this system is not well formed.
            boolean wellformed = true;
            if( counts[0]!=1 ) wellformed = false;
            if( counts[25]!=1 ) wellformed = false;
            for( int i=1; i<25; i++ )
            {
                if( counts[i]!=0 ) wellformed = false;
            }

            // If well formed, then the answer is just the resistance between A and Z.
            // If not, we'll use -1.0
            ps.printf( "%.3f", wellformed ? resistance[0][25] : -1.0 );
            ps.println();
        }
    }

	public static void main(String[] args) throws Exception
	{
		new circuits_judge().doit();
	}
}
