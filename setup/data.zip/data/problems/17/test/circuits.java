/*
Author: Yiu Yu Ho

Just simplify the circuit as described in the problem statement

The addEdge and remove methods below makes the job easier.
*/

import java.util.*;
import java.io.*;
import java.text.*;

public class circuits
{
	public static DecimalFormat fmt=new DecimalFormat("0.000");

	public final double tol = 1e-12;

	public Scanner in = new Scanner(System.in);
	public PrintStream out = System.out;

	public double[][] G;
	public boolean[][] R;
	
	public int[] deg;

	public void main()
	{
		int i,j,k,x,y;
		double r;
		boolean done;
		int n;

		n = in.nextInt();
		while(n>0)
		{
			G=new double[26][26];
			R=new boolean[26][26];
			deg=new int[26];

			for(i=0;i<n;++i)
			{
				x=(in.next().charAt(0)-'A');
				y=(in.next().charAt(0)-'A');
				r=in.nextDouble();

				addEdge(x,y,r);
			}

			done=false;
			while(!done)
			{
				done=true;
				for(i=1;i<=24;++i)
				if(deg[i]==2)
				{
					x=next(i,0);
					y=next(i,x+1);
					addEdge(x,y,G[i][x]+G[i][y]);
					remove(i,x,y);
					done=false;
				}
			}

			k=0;
			for(x=0;x<26;++x)
			for(y=x+1;y<26;++y)
			if(R[x][y]) ++k;

			if(k==1 && R[0][25])
			{
				out.println(fmt.format(G[0][25]+tol));
			}
			else
			{
				out.println("-1.000");
			}

			n = in.nextInt();
		}
	}

	public int next(int i,int j)
	{
		while(j<26 && !R[i][j]) ++j;
		return j;
	}

	public void remove(int i,int x,int y)
	{
		deg[i] = 0;
		R[i][x]=R[x][i]=false;
		R[i][y]=R[y][i]=false;
		--deg[x]; --deg[y];
	}

	public void addEdge(int x,int y,double r)
	{
		if(!R[x][y])
		{
			R[x][y] = R[y][x] = true;
			++deg[x]; ++deg[y];
			G[x][y] = G[y][x] = r;
		}
		else
		{
			double R,R1,R2;
			R1 = G[x][y];
			R2 = r;
			R = (R1*R2)/(R1+R2);
			G[x][y] = G[y][x] = R;
		}
	}

	public static void main(String[] args)
	{
		long startTime = System.currentTimeMillis();
		(new circuits()).main();
		System.err.println("Time = "+(System.currentTimeMillis()-startTime)+"(ms)");
	}
}
