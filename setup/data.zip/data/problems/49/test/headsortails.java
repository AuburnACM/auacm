
import java.io.*;
import java.lang.reflect.Array;
import java.util.*;
import java.awt.geom.*;

/**
 * Solution to Heads or Tails
 * 
 * @author vanb
 */
public class headsortails
{
    public Scanner sc;
    public PrintStream ps;
        
    /**
     * Compute nCm, the number of ways to randomly
     * select m things from a group of n, where order doesn't matter.
     * 
     * @param n n
     * @param m m
     * @return nCm
     */
    public long choose( long n, long m )
    {
        long result = 1L;
        if( m>=0 && n>=m )
        {
            m = Math.min( m, n-m );
            for( long i=0; i<m; i++ )
            {
                result *= n-i;
                result /= i+1;
            }
        }
        
        return result;
    }
        
    /**
     * Driver.
     * @throws Exception
     */
    public void doit() throws Exception
    {
        sc = new Scanner( System.in ); //new File( "headsortails.judge" ) );
        ps = System.out; //new PrintStream( new FileOutputStream( "headsortails.out" ) ); 
        
        // counts[i] is the number of coins on the board with 
        // exactly i neighbors (including itself) that would
        // cause a flip if pressed.
        int counts[] = new int[6];
        
        // prob[i] is the probability that a coin with 
        // i neighbors (including itself) will remain a Head
        // after k random presses.
        double prob[] = new double[6];
        
        // heads[i] is the number of coins with i neighbors (including itself)
        // that we've placed so far that are heads
        int heads[] = new int[6];
        
        // This is a list of all of the starting configurations
        // which will yield an acceptable number of Heads after
        // k random presses.
        //
        // A configuration is an array [0..6], where config[i] is
        // the number of coins with i neighbors (including itself).
        LinkedList<int[]> configs = new LinkedList<int[]>();
        
        // adjacents[i][j] is the number of adjacent coins (including itself)
        // of the coin at board position (i,j)
        int adjacents[][] = new int[7][7];
                        
        for(;;)
        {
            /// Read in the 6 parameters
            int n = sc.nextInt();
            int m = sc.nextInt();
            int k = sc.nextInt();
            int a = sc.nextInt();
            int b = sc.nextInt();
            long c = sc.nextLong();
            if( n==0 && m==0 ) break;
            
            // Total number of coins on the board
            double ncoins = n*m;
                        
            // Compute counts[] and adjacents[][]
            Arrays.fill( counts, 0 );
            for( int i=0; i<n; i++ ) for( int j=0; j<m; j++ )
            {
                // Max of 5 adjacents: the coin itself and 4 neighbors
                int adj = 5;
                
                // Subtract 1 for each edge that the coin is on
                if( i==0 ) --adj;
                if( i==n-1 ) --adj;
                if( j==0 ) --adj;
                if( j==m-1 ) --adj;
                
                // Remember!
                adjacents[i][j] = adj;
                ++counts[adj];
            }
            
            // Compute the probability of a Head staying a Head after
            // k random moves for each of the types of coins. 
            
            // At the beginning (after 0 moves) the probability of
            // a Head staying a Head is 1 if there's a coin there to begin with,
            // otherwise 0
            for( int j=0; j<6; j++ ) prob[j] = counts[j]>0 ? 1.0 : 0.0;
            
            // Go through k random presses
            for( int i=0; i<k; i++ )
            {
                // j is the number of neighbors
                for( int j=0; j<6; j++ ) if( counts[j]>0 )
                {
                    // At each step, the coin is a Head if:
                    // 1) It starts out as a head and you press one of the ncoins-j other coins
                    //    that won't flip it, or
                    // 2) It starts out as a tail, and you press one of the j coins that flips it
                    prob[j] = prob[j]*((ncoins-j)/ncoins) + (1.0-prob[j])*(j/ncoins);    
                }
            }
                        
            // Figure out the expected number of Heads
            // if we start with a given configuration.
            // If it's in the range of interest, remember it.
            // (We'll skip 0. Since we count the coin itself as a neighbor,
            // every coin must have at least one neighbor.)
            configs.clear();
            for( int i1=0; i1<=counts[1]; i1++ ) 
            for( int i2=0; i2<=counts[2]; i2++ ) 
            for( int i3=0; i3<=counts[3]; i3++ ) 
            for( int i4=0; i4<=counts[4]; i4++ ) 
            for( int i5=0; i5<=counts[5]; i5++ )
            {
                double expected = i1*prob[1] + (counts[1]-i1)*(1.0-prob[1]);
                expected += i2*prob[2] + (counts[2]-i2)*(1.0-prob[2]);
                expected += i3*prob[3] + (counts[3]-i3)*(1.0-prob[3]);
                expected += i4*prob[4] + (counts[4]-i4)*(1.0-prob[4]);
                expected += i5*prob[5] + (counts[5]-i5)*(1.0-prob[5]);
                   
                // If the expected number of heads is in the range [a,b], then
                // remember the configuration
                if( a<=expected && expected<=b )
                {
                    configs.add( new int[] { 0, i1, i2, i3, i4, i5 } );
                }
            }
                        
            // Build up the grid
            char grid[][] = new char[n][m];
            Arrays.fill( heads, 0 );
            long index = 0L;
            for( int i=0; i<n; i++ ) for( int j=0; j<m; j++ )
            {
                // Determine the type of this coin
                int type = adjacents[i][j];
                
                // Make it a head, see what happens
                ++heads[type];
                --counts[type];
                
                // See how many configs follow this one
                long increment = 0L;
                for( int config[] : configs )
                {
                    // Determine if the config is still possible
                    boolean possible = true;                    
                    for( int t=0; t<6 && possible; t++ )
                    {
                        // If what we need minus what we've already placed is
                        // more than we've got left, then we're hosed.
                        if( config[t]-heads[t]>counts[t] ) possible=false;
                        
                        // If we already have placed more than we need, we're hosed.
                        if( config[t]<heads[t] ) possible=false;
                    }
                    
                    if( possible )
                    {
                        // If we make this coin a Head, figure out
                        // how many OK boards follow this one.
                        long total = 1L;
                        for( int t=0; t<6; t++ ) if( counts[t]>0 )
                        {
                            // This is the total number of ways to fill
                            // the slots we haven't filled yet, with
                            // the number of Heads we need.
                            total *= choose( counts[t], config[t]-heads[t] );
                        }
                        increment += total;
                    }
                }
                                
                // Does this not take us far enough?
                if( index+increment<c )
                {
                    // If not, then this coin can't be a Head.
                    // It has to be a Tail.
                    grid[i][j] = 'T';
                    
                    // That's one less Head we're using
                    --heads[type];
                    
                    // If it's a Tail, we bypass all of those board positions 
                    // that would have followed if it was a Head.
                    index += increment;
                }
                else
                {
                    // Otherwise, it's a head
                    grid[i][j] = 'H';
                }
                    
            }
            
            // Print the result
            for( int i=0; i<n; i++ )
            {
                ps.println( new String( grid[i] ) );
            }
        }
    }
    
    /**
     * @param args
     */
    public static void main( String[] args ) throws Exception
    {
        new headsortails().doit();
    }

}
