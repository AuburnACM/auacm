
import java.io.*;
import java.util.*;
import java.awt.geom.*;

/**
 * Solution to Gold Leaf
 * 
 * @author vanb
 */
public class goldleaf_vanb
{
    public Scanner sc;
    public PrintStream ps;
    
    /**
     * A class to hold & compare solutions
     * 
     * @author vanb
     */
    public class Solution implements Comparable<Solution>
    {
        /** (li,lj), (ri,rj) */
        public int li, lj, ri, rj;
        
        /**
         * Create a solution
         * 
         * @param li Left i
         * @param lj Left j
         * @param ri Right i
         * @param rj Right j
         */
        public Solution( int li, int lj, int ri, int rj )
        {
            this.li = li;
            this.lj = lj;
            this.ri = ri;
            this.rj = rj;
        }

        @Override
        /**
         * Compare one solution to another
         * 
         * @param s Another solution
         * @return negative if this solution is "better" than s, non-negative otherwise
         */
        public int compareTo( Solution s )
        {
            int diff = li - s.li;
            if( diff==0 ) diff = lj - s.lj;
            if( diff==0 ) diff = ri - s.ri;
            if( diff==0 ) diff = rj - s.rj;
            return diff;
        }
        
        /**
         * Convert this solution to a printable string
         * 
         * @return A printable string
         */
        public String toString()
        {
            return "" + li + " " + lj + " " + ri + " " + rj;
        }
    }
    
    /** Start with an impossible solution that we'll replace when we get a real one. */
    public Solution solution = new Solution( 100, 100, 100, 100 );
    
    /**
     * Check to seee if a new solution is the best solution.
     * 
     * @param r1 Row of coord 1
     * @param c1 Column of coord 1
     * @param r2 Row of coord 2
     * @param c2 Column of coord 2
     */
    public void checkSolution( int r1, int c1, int r2, int c2 )
    {
        Solution newsol = new Solution( r1, c1, r2, c2 );
        if( newsol.compareTo( solution ) < 0 ) solution = newsol;
    }
           
    /**
     * Driver.
     * @throws Exception
     */
    public void doit() throws Exception
    {
        sc = new Scanner( System.in );
        ps = System.out; 
        
        int n = sc.nextInt();
        int m = sc.nextInt();
        
        // Read in the image, count the number of cells that
        // represent exposed paper
        char sheet[][] = new char[n][];
        int paper = 0;
        for( int i=0; i<n; i++ )
        {
            sheet[i] = sc.next().toCharArray();
            for( int j=0; j<m; j++ ) if( sheet[i][j]=='.' ) ++paper;
        }
                
        // First, check horizontal folds
        for( int i=1; i<n; i++ )
        {
            // This is how many rows we must check
            int limit = Math.min( i, n-i );
            
            // Make sure that all cells in the same position
            // on opposite sides of the fold are different.
            boolean found = true;
            int count = 0;
            for( int j=0; j<m && found; j++ ) for( int k=0; k<limit && found; k++ )
            {
                ++count;
                found = (sheet[i+k][j]!=sheet[i-k-1][j]);
            }
            
            // It's only a solution if all of the exposed paper cells are covered
            if( found && count==paper ) checkSolution( i, 1, i, m );
        }
        
        // Next, check vertical. Same logic as horizontal.
        for( int j=1; j<m; j++ )
        {
            int limit = Math.min( j, m-j );
            boolean found = true;
            int count = 0;
            for( int i=0; i<n && found; i++ ) for( int k=0; k<limit && found; k++ )
            {
                ++count;
                found = (sheet[i][j+k]!=sheet[i][j-k-1]);
            }
            if( found && count==paper ) checkSolution( 1, j, n, j );
        }
       
        // Now, diagonal like this: /
        // This is the maximum number of diagonals we need to check.
        // Consider 4x3. Since folding just the corners would have no
        // effect, there are 4+3-3 = 4 diagonals you need to check.
        //    12
        //  X//3
        //  ///4
        //  ///
        //  //X
        //
        // Let's look at a larger case: 5x7
        //   123456
        // X//////7
        // ///////8
        // ///////9
        // ///////
        // //////X
        // There are 5+7-3 = 9 diagonals to check.
        int max = n+m-3;
        
        // Check all diagonals
        for( int limit=1; limit<=max; ++limit )
        {
            int count = 0;
            boolean found = true;
            // Look at all cells above the diagonal
            for( int i=0; i<limit && found; i++ ) for( int j=0; j<limit-i && found; j++ )
            {
                // This is the cell's reflection
                int newi = limit-j;
                int newj = limit-i;
                
                // Is it on the paper?
                if( newi>=0 && newi<n && newj>=0 && newj<m )
                {
                    ++count;
                    
                    // Are the cell and its reflection different? 
                    found = (sheet[i][j]!=sheet[newi][newj]);
                }
            }
            
            // Left i, Left j, Right i, Right j
            int li=0, lj=0, ri=0, rj=0;
            
            // If limit is <n, then
            // the left end of the diagonal is along the left edge
            if( limit<n )
            {
                li = limit+1;
                lj = 1;
            }
            else
            {
                // Otherwise, it's on the bottom edge.
                li = n;
                lj = limit - n + 2;
            }
            
            // Same deal here. If limit<m, then
            // the right end is along the top.
            if( limit<m )
            {
                ri = 1;
                rj = limit+1;
            }
            else
            {
                // Otherwise, it's on the right edge.
                ri = limit - m + 2;
                rj = m;
            }
            if( found && count==paper ) checkSolution( li, lj, ri, rj );
        }
        
        // Finally, diagonal like this: \
        // Uses the same logic as the / diagonal
        for( int limit=1; limit<=max; ++limit )
        {
            int count = 0;
            boolean found = true;
            for( int i=0; i<limit && found; i++ ) for( int j=m-limit+i; j<m && found; j++ )
            {
                int newi = j-m+limit+1;
                int newj = m-limit+i-1;
                if( newi>=0 && newi<n && newj>=0 && newj<m )
                {
                    ++count;
                    found &= (sheet[i][j]!=sheet[newi][newj]);
                }
            }
            
            int li=0, lj=0, ri=0, rj=0;
            if( limit<m )
            {
                li = 1;
                lj = m - limit;
            }
            else
            {
                li = limit - m + 2;
                lj = 1;
            }
            
            if( limit<n )
            {
                ri = limit+1;
                rj = m;
            }
            else
            {
                ri = n;
                rj = max - limit + 2;
            }

            if( found && count==paper ) checkSolution( li, lj, ri, rj );
        }
        
        // Finally, just print the solution.
        ps.println( solution );
    }
    
    /**
     * @param args
     */
    public static void main( String[] args ) throws Exception
    {
        new goldleaf_vanb().doit();
    }   
}
