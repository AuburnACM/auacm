
import java.io.*;
import java.util.*;
import java.awt.geom.*;

/**
 * Solution to Candy Store
 * 
 * @author vanb
 */
public class candystore
{
    public Scanner sc;
    public PrintStream ps;
        
    /**
     * Driver.
     * @throws Exception
     */
    public void doit() throws Exception
    {
        sc = new Scanner( System.in ); //new File( "candystore.in" ) );
        ps = System.out; //new PrintStream( new FileOutputStream( "candystore.out" ) ); 
        
        // best[i] will be the best number of calories you can get
        // by spending i cents.
        int best[] = new int[10001];
        
        // This will be the final answer
        int fattest = 0;
        
        // These arrays will hold the info for 
        // different types of candy
        int calories[] = new int[5000];
        int cost[] = new int[5000];
                        
        for(;;)
        {
            int n = sc.nextInt();
            
            // Read the max money - in pennies
            int m = (int)Math.round( sc.nextDouble()*100 );
            if( n==0 ) break;  
            
            for( int i=0; i<n; i++ )
            {
                calories[i] = sc.nextInt();
                
                // Read the costs in pennies
                cost[i] = (int)Math.round( sc.nextDouble()*100 );
            }
            
            Arrays.fill( best, 0 );
            fattest = 0;
            int lastbest = -1;
            
            // Go through the amount to spend, penny by penny.
            for( int i=0; i<m; i++ ) if( best[i]>lastbest )
            {
                lastbest = best[i];
                
                // Go through all of the different types of candy
                for( int j=0; j<n; j++ ) 
                {
                    // This is the cost if you buy this kind of candy
                    // at this point 
                    int target = i+cost[j];
                    
                    // This is the total calories if you buy this 
                    // kind of candy at this point
                    int fatness = best[i]+calories[j];
                    if( target<=m && fatness>best[target] )
                    {
                        best[target] = fatness;
                        
                        // Have to check the best here.
                        // The best might not occur at the max $
                        if( fatness>fattest ) fattest = fatness;
                    }
                }
            }
            
            ps.println( fattest );
        }
    }
    
    /**
     * @param args
     */
    public static void main( String[] args ) throws Exception
    {
        new candystore().doit();
    }

}
