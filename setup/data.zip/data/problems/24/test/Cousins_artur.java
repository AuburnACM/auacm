import java.util.Scanner;

public class Cousins_artur {

  public static void main(String[] args) {
    Scanner in = new Scanner(System.in);
    for (int n = in.nextInt(), k = in.nextInt(); !(n == 0 && k == 0); n = in.nextInt(), k = in.nextInt()) {
      int nodeK = -1;
      int[] node = new int[n];
      for (int i = 0; i < n; i++) {
        node[i] = in.nextInt();
        if (node[i] == k)
          nodeK = i;
      }

      int[] parent = new int[n];
      int current = parent[0] = -1;
      for (int i = 1; i < n; i++) {
        if (node[i] != node[i - 1] + 1)
          current++;
        parent[i] = current;
      }

      int cousins = 0;
      if (parent[nodeK] != -1)
        for (int i = 1; i < n; i++)
          if (parent[parent[i]] == parent[parent[nodeK]] && parent[i] != parent[nodeK])
            cousins++;
      System.out.println(cousins);
    }
  }
}
