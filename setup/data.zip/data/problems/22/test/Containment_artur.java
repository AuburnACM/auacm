import java.util.Arrays;
import java.util.LinkedList;
import java.util.Scanner;

public class Containment_artur {

  static final int INF = Integer.MAX_VALUE / 3, D = 10;
  static final int n = D * D * D + 2, m = n * 16 + 1, source = n - 2, sink = n - 1;

  static int counter = 0;
  static int[] head = new int[n], temp = new int[n], level = new int[n];
  static int[] tail = new int[m], prev = new int[m], flow = new int[m], cap = new int[m];

  static {
    Arrays.fill(head, -1);
    for (int x = 0; x < D; x++)
      for (int y = 0; y < D; y++) {
        for (int z = 0; z < D; z++) {
          if (x != D - 1) addEdge(idx(x, y, z), idx(x + 1, y, z), 1, 1);
          if (y != D - 1) addEdge(idx(x, y, z), idx(x, y + 1, z), 1, 1);
          if (z != D - 1) addEdge(idx(x, y, z), idx(x, y, z + 1), 1, 1);
        }
        addEdge(idx(x, y, 0), sink, 1, 0);
        addEdge(idx(x, 0, y), sink, 1, 0);
        addEdge(idx(0, x, y), sink, 1, 0);
        addEdge(idx(x, y, D - 1), sink, 1, 0);
        addEdge(idx(x, D - 1, y), sink, 1, 0);
        addEdge(idx(D - 1, x, y), sink, 1, 0);
      }
  }

  public static void main(String[] args) throws Exception {
    Scanner in = new Scanner(System.in);

    int n = in.nextInt();
    for (int i = 0; i < n; i++) {
      int id = idx(in.nextInt(), in.nextInt(), in.nextInt());
      addEdge(source, id, 6, 0);
    }

    System.out.println(getMaxFlow());
  }

  private static int idx(int x, int y, int z) {
    if (0 <= x && x < D && 0 <= y && y < D && 0 <= z && z < D)
      return x + D * (y + D * z);
    else {
      System.out.println("SINK");
      return sink;
    }
  }

  private static void addEdge(int s, int t, int forward, int backward) {
    newEdge(s, t, forward);
    newEdge(t, s, backward);
  }

  private static void newEdge(int s, int t, int f) {
    tail[counter] = t;
    cap[counter] = f;
    flow[counter] = 0;
    prev[counter] = head[s];
    head[s] = counter++;
  }

  private static int getMaxFlow() {
    int flow = 0;
    while (bfs()) {
      for (int i = 0; i < n; i++)
        temp[i] = head[i];
      while (true) {
        int augFlow = dfs(source, INF);
        if (augFlow == 0) break;
        flow += augFlow;
      }
    }
    return flow;
  }

  private static boolean bfs() {
    Arrays.fill(level, -1);
    level[source] = 0;
    LinkedList<Integer> queue = new LinkedList<Integer>();
    queue.add(source);
    while (!queue.isEmpty()) {
      int s = queue.poll();
      for (int e = head[s]; e >= 0; e = prev[e]) {
        int t = tail[e];
        if (level[t] == -1 && flow[e] < cap[e]) {
          level[t] = level[s] + 1;
          queue.add(t);
        }
      }
    }
    return level[sink] >= 0;
  }

  private static int dfs(int s, int f) {
    if (s == sink) return f;
    for (int e = temp[s]; e >= 0; temp[s] = e = prev[e]) {
      int t = tail[e];
      if (level[t] == level[s] + 1 && flow[e] < cap[e]) {
        int df = dfs(t, Math.min(f, cap[e] - flow[e]));
        if (df > 0) {
          flow[e] += df;
          flow[e ^ 1] -= df;
          return df;
        }
      }
    }
    return 0;
  }

}

