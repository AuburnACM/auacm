
// O(N^2 log N) solution to Alchemy

import java.util.*;

public class Alchemy
{
   public static void main(String[] args)
   {
      new Alchemy(new Scanner(System.in));
   }

   int N, dfsTimer;
   ArrayList<Circle> circles;

   void dfs(Circle cur)
   {
      cur.pre = dfsTimer++;
      for (Circle nxt : cur.children)
         dfs(nxt);
      cur.post = dfsTimer++;
   }

   // O(N log N) findBest.
   Circle findBest()
   {
      TreeSet<Integer> endangered = new TreeSet<Integer>();
      for (Circle cur : circles)
         if (cur.isEndangered())
            endangered.add(cur.pre);
      for (Circle cur : circles)
         if (cur.isOptimal())
         {
            // Check to make sure we are not effecting endangered children
            Integer nxt = endangered.higher(cur.pre);
            if (nxt == null || nxt.intValue() > cur.post)
               return cur;
         }
      return null;
   }

   public Alchemy(Scanner in)
   {
      N = in.nextInt();

      circles = new ArrayList<Circle>(N);
      for (int i=0; i<N; i++)
         circles.add(new Circle(i, in.nextInt(), in.nextInt(), in.nextInt(), in.nextInt(), in.nextInt()));

      for (Circle a : circles)
         for (Circle b : circles)
            if (a.contains(b))
               b.numParents++;
     
      for (Circle a : circles)
      {
         // Find the smallest circle that contains us (if any)
         Circle best = null;
         for (Circle b : circles)
            if (b.contains(a) && (best == null || best.r > b.r))
               best = b;
         if (best != null)
            best.children.add(a);
      }

      for (Circle a : circles)
         a.calcMaximums();
      
      dfsTimer = 0;
      for (Circle a : circles)
         if (a.numParents == 0)
            dfs(a);

      int res = 0;
      for (Circle cur : circles)
         res += cur.maxReward;
      System.out.println(res);

      StringBuilder sb = new StringBuilder();
      while (circles.size() > 0)
      {
         Circle best = findBest();
         circles.remove(best);

         for (Circle a : circles)
            if (best.contains(a))
               a.numParents--;

         sb.append(best.i+1);
         sb.append(' ');
      }
      System.out.println(sb.toString().trim());
   }
}

class Circle
{
   int i, x, y, r, a, b;
   long r2;
   int firstMax, lastMax, maxReward, cycleLen, numParents, pre, post;
   ArrayList<Circle> children;

   public Circle(int ii, int xx, int yy, int rr, int aa, int bb)
   {
      i=ii; x=xx; y=yy; r=rr; a=aa; b=bb;
      r2 = r*1L*r;

      firstMax = lastMax = maxReward = -987654321;
      numParents = 0;
      cycleLen = -1;
      if (a == -b)
      {
         if (a == 0)
            cycleLen = 1;
         else
            cycleLen = 2;
      }

      pre = post = -1;
      children = new ArrayList<Circle>();
   }

   boolean isOptimal()
   {
      if (cycleLen < 0)
         return firstMax == numParents || lastMax == numParents;
      if (numParents > firstMax || numParents < lastMax)
         return false;
      return (firstMax-numParents) % cycleLen == 0;
   }

   boolean isEndangered()
   {
      return numParents == lastMax;
   }

   int calcReward(int numSteps)
   {
      int sum = (numSteps/2)*(a+b);
      if (numSteps%2 == 1)
         sum += a;
      return sum;
   }

   void calcMaximums()
   {
      firstMax = 0;
      lastMax = numParents;

      maxReward = 0;
      for (int i=0; i<=numParents; i++)
         maxReward = Math.max(maxReward, calcReward(i));
      for (int i=0; i<=numParents; i++)
         if (maxReward == calcReward(i))
         {
            if (lastMax == numParents)
               lastMax = i;
            firstMax = i;
         }
   }

   boolean contains(Circle rhs)
   {
      return rhs.r < r && contains(rhs.x, rhs.y);
   }

   boolean contains(int rx, int ry)
   {
      int xx = x-rx, yy = y-ry;
      long d2 = xx*1L*xx+yy*1L*yy;
      return d2 < r2;
   }
}
