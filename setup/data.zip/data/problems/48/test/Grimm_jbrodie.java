import java.io.*;
import java.util.Scanner;

import java.util.Arrays;
import java.util.ArrayList;

/**
 * Grimm, ACM ICPC SER 2012 (10.nov.2012)
 *
 * @author john brodie
 * 
 */
class Grimm_jbrodie {

   private static long [] primes;
   private static int count;
   private static final int MAX = 100000;

   private static void init_primes() {
      primes = new long[100000];
      count = 0;

      boolean [] isPrime = new boolean[MAX];
      isPrime[0] = false; isPrime[1] = false;
      for( int i = 2; i < isPrime.length; ++i ) isPrime[i]=true;
      
      for( int i = 2; i < isPrime.length; ++i ) {
         if( isPrime[i] ) {
            primes[count] = (long)i;
            ++count;
            for(int j=i+i; j < isPrime.length; j+=i ) isPrime[j] = false;
         }
      }

      // System.err.format("there are %d primes less than %d%n",count,MAX);
      // System.err.format("and they are:");
      // int count = 0;
      // for( long l : primes ) {
      //    if( count % 15 == 0 ) System.err.format("%n");
      //    System.err.format(" %d",l);
      //    ++count;
      // }
      // System.err.format("%n");
      
   }

   private static ArrayList<Long> factor(long n) {
      ArrayList<Long> result = new ArrayList<Long>();
      for( int i = 0; i < count; ++i ) {
         long tmp = primes[i];
         if( tmp > n ) break;
         if( n % tmp == 0 ) {
            result.add(tmp);
            while( n % tmp == 0 ) n = n / tmp;
         }
      }
      if( n != 1 ) result.add(n);
      return result;
   }

   private static ArrayList<Long> [] factors;

   private static long[] solve(long min, long max) {
         int count = (int)(max - min) + 1;
         long[] result = new long[count];
         Arrays.fill(result,0);

         factors = new ArrayList[count];
         for(int i = 0; i < count; ++i) {
            factors[i] = factor(min+i);

            // System.err.format("factor(%d)=",min+i);
            // for(long l : factors[i]) System.err.format("%d ",l);
            // System.err.format("%n");
         }

         boolean solving = true;
      outer:
         while( solving ) {
            solving = false;
            for(int i=0; i < count; ++i) {
               if( factors[i].size() == 1 ) {
                  long tmp = factors[i].remove(0);
                  //System.err.format("single %d in factors[%d]%n",tmp,i);
                  for( ArrayList<Long> x : factors ) {
                     x.remove(tmp);
                  }
                  result[i] = tmp;
                  solving = true;
               }
            }
            if( ! solving ) {
               // no singles in list, pick least element from leftmost remaining
               for(int i=0; i < count; ++i) {
                  if( result[i] == 0 ) {
                     long tmp = factors[i].remove(0);
                     //System.err.format("removed %d from factors[%d]%n",tmp,i);
                     factors[i].clear();
                     for( ArrayList<Long> x : factors ) {
                        x.remove(tmp);
                     }
                     result[i] = tmp;
                     solving = true;
                     break;
                  }
               }
            }
         }

         return result;
   }

   public static void main( String[] args ) throws IOException {

      Scanner in =
         new Scanner(new BufferedReader(new InputStreamReader(System.in)));

      init_primes();

      for(;;) {

         long min = in.nextLong();
         long max = in.nextLong();
         if( (min==0) && (max==0) ) break;

         long[] solution = solve(min,max);
         System.out.format("%d",solution[0]);
         for(int i = 1; i < solution.length; ++i) {
            System.out.format(" %d",solution[i]);
         }
         System.out.format("%n");
      }
   }
}