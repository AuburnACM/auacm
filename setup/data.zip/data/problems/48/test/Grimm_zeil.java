import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;

/**
 * 
 */

/**
 * @author zeil
 *
 */
public class Grimm_zeil {
	
	static public class PNode {
		long data;
		PNode next;
		
		public PNode(long d, PNode nx) {
			data = d;
			next = nx;
		}
	}
	
	private static PNode firstPrime;
	private static PNode lastPrime;
	
	private static int numPrimes;

	private long min, max;
	
	public Grimm_zeil(long mn, long mx) {
		min = mn;
		max = mx;
	}



	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main (String[] argv) throws IOException
	{
		BufferedReader in;
		if (argv.length > 0)
		{
			in = new BufferedReader(new FileReader(argv[0]));
		}
		else {
			in = new BufferedReader (new InputStreamReader(System.in));
		}
		run (in);
	}
	
	
	static private long MaxLimit = 10000000000L;
	private static void run(BufferedReader in) throws IOException {
		precomputePrimes(MaxLimit);
		Scanner input = new Scanner(in);
		long min, max;
		min = input.nextLong();
		while (min > 0) {
			max = input.nextLong();
			if (min < 4L || max > MaxLimit) {
				System.err.println ("Illegal test case " + min + " " + max);
			}
			processDataSet (min, max);
			min = input.nextLong();
		}
	}


	static int problemNum = 0;
	private static void processDataSet(long min, long max) {
		//System.err.println ("" + problemNum + ": " + min + "..." + max);
		++problemNum;
		Grimm_zeil problem = new Grimm_zeil (min, max);
		problem.solve();
	}



	private static void precomputePrimes(long limit) {
		firstPrime = lastPrime = new PNode(2L, null);
		numPrimes = 1;
		long t = 3L;
		while (t*t < limit) {
			if (isPrime(t)) {
				//System.err.println (t);
				lastPrime.next = new PNode(t, null);
				lastPrime = lastPrime.next;
				++numPrimes;
			}
			t  += 2L;
		}
		//System.err.println ("Found " + numPrimes + " primes");
		long max = 0;
		long start = 0;
		long stop = 0;
		PNode prev = firstPrime;
		PNode current = prev.next;
		while (current != null) {
			if (max < current.data - prev.data) {
				start = prev.data;
				stop = current.data;
				max = stop - start;
			}
			prev = current;
			current = current.next;
		}
		//System.err.println ("Longest interval = " + max + " from " + start + " to " + stop);
		
	}



	private static boolean isPrime(long t) {
		for (PNode p = firstPrime; p != null; p = p.next) {
			if (t % p.data == 0)
				return false;
			if (p.data*p.data > t)
				break;
		}
		return true;
	}


	long[] result;
	ArrayList<Long>[] factors;
	private void solve() {
		int interval = (int)(max - min) + 1;
		factors = new ArrayList[interval];
		for (int i = 0; i < interval; ++i)  {
			factors[i] = factor(min + (long)i);
		}
		
		
		result = new long[interval];
		Arrays.fill(result, 0);
		boolean OK = solve(0);
		if (OK) {
			boolean first = true;
			for (long k: result) {
				if (!first)
					System.out.print(' ');
				System.out.print(k);
				first = false;
			}
			System.out.println();
		}
		else
			System.out.println("Something went wrong: " + min + " " + max);
	}
	
	
	private boolean solve(int cnt) {
		if (cnt >= result.length)
			return true;
		ArrayList<Long>[] remainingChoices = new ArrayList[result.length]; 
		HashSet<Long> used = new HashSet<Long>();
		for (int i = 0; i < result.length; ++i) {
			if (result[i] > 0) {
				used.add(result[i]);
			}
		}
		// Search for contradictions
		for (int i = 0; i < result.length; ++i) {
			if (result[i] <= 0) {
				ArrayList<Long> choices = getChoices(i, used);
				if (choices.size() == 0)
					return false;
				remainingChoices[i] = choices;
			}
		}
		// Search for forced assignments
		for (int i = 0; i < result.length; ++i) {
			if (result[i] <= 0) {
				ArrayList<Long> choices = remainingChoices[i];
				if (choices.size() == 1) {
					long p = choices.get(0);
					result[i] = p;
					if (solve(cnt+1)) {
						return true;
					} else {
						result[i] = 0;
						return false;
					}
				}
			}
		}
		// Run through the possibilities for the leftmost unassigned slot
		for (int i = 0; i < result.length; ++i) {
			if (result[i] <= 0) {
				ArrayList<Long> choices = remainingChoices[i];
				for (long p: choices) {
					result[i] = p;
					if (solve(cnt+1))
						return true;
				}
				result[i] = 0;
				return false;
			}
		}
		return false;
	}



	private ArrayList<Long> getChoices(int i, HashSet<Long> used) {
		ArrayList<Long> choices = new ArrayList<Long>();
		for (long p: factors[i]) {
			if (!used.contains(p))
				choices.add(p);
		}
		return choices;
	}



	// Returns unique factors of num
	private ArrayList<Long> factor(long num) {
		long onum = num;
		ArrayList<Long> factors = new ArrayList<Long>();
		PNode k = firstPrime;
		while (k != null) {
			long p = k.data;
			if (p*p > num) break;
			if (num % p == 0) {
				num = num / p;
				int j = factors.size();
				if (j == 0 || p != factors.get(j-1))
					factors.add(p);
			} else {
				k = k.next;
			}
		}
		if (num > 1L) {
			if (num == onum) {
				System.err.println ("Illegal input: " + onum + " is prime.");
			}
			factors.add(num);
		}
		return factors;
	}




	
	
}
