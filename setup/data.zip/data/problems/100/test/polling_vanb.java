import java.util.*;
import java.util.regex.*;
import java.io.*;

/**
 * Solution to Polling
 * 
 * @author vanb
 */
public class polling_vanb
{
    public Scanner sc;
    public PrintStream ps;
            
    public void doit() throws Exception
    {
        sc = new Scanner( System.in );
        ps = System.out;
        
        // A HashMap to hold the count of votes for each candidate
        HashMap<String,Integer> counts = new HashMap<String,Integer>();
        
        // A list of the best candidates
        LinkedList<String> best = new LinkedList<String>();
        
        int n = sc.nextInt();
        int max = 0;
        
        for( int i=0; i<n; i++ )
        {
            String candidate = sc.next();
            
            // Look for this candidate in the HashMap
            Integer count = counts.get( candidate );
            
            // If not there, then the candidate hasn't gotten any votes yet
            if( count==null ) count=0;
            
            // One more vote
            ++count;
            
            // Put it back in the HashMap
            counts.put( candidate, count );
            
            // If this candidate ties for the max,
            // put'em in the best list
            if( count==max ) best.add( candidate );
            else if( count>max )
            {
                // If this candidate is better than any we've seen before,
                // clear out the best list.
                max = count;
                best.clear();
                best.add( candidate );
            }
        }
        
        // Sort the winners
        String winners[] = (String[])best.toArray(new String[best.size()]);
        Arrays.sort( winners );
        
        // And, print them
        for( String winner : winners )
        {
            ps.println( winner );
        }
    }
    
    public static void main( String[] args ) throws Exception
    {
        new polling_vanb().doit();
    }

}
