import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.TreeSet;

public class Polling_artur {
  public static void main(String[] args) throws Exception {
    BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    int n = Integer.parseInt(in.readLine()), max = Integer.MIN_VALUE;
    int[] count = new int[n];
    HashMap<String, Integer> ids = new HashMap<String, Integer>();
    for (int i = 0, idx; i < n; i++) {
      String name = in.readLine();
      ids.putIfAbsent(name, ids.size());
      idx = ids.get(name);
      max = Math.max(++count[idx], max);
    }
    TreeSet<String> winners = new TreeSet<String>();
    for (String candidate : ids.keySet())
      if (count[ids.get(candidate)] == max) winners.add(candidate);
    for (String winner : winners)
      System.out.println(winner);
  }
}
