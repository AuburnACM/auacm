import java.util.*;

public class Voting {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        for (String s = scan.nextLine(); !s.equals("#"); s = scan.nextLine()) {

            int votes = 0;
            int absent = 0;
            int yes = 0;
            int no = 0;
            for (Character c : s.toCharArray()) {
                switch (c) {
                    case 'Y':
                        votes++;
                        yes++;
                        break;
                    case 'N':
                        votes++;
                        no++;
                        break;
                    case 'P':
                        votes++;
                        break;
                    case 'A':
                        absent++;
                        break;
                }
            }

            // System.out.println("yes = " + yes);
            // System.out.println("no = " + no);
            // System.out.println("absent = " + absent);
            // System.out.println("votes = " + votes);

            if (absent >= votes) {
                System.out.println("need quorum");
            } else if (yes > no) {
                System.out.println("yes");
            } else if (no > yes) {
                System.out.println("no");
            } else {
                System.out.println("tie");
            }


        }
    }

}